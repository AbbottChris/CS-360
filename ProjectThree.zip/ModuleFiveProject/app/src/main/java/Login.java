public class Login {
    public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

        private InventoryDatabase mInvDb;
        private TextView mUserText;
        private TextView mPassText;
        private Button mLoginButton;
        private Button mRegisterButton;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);

            // load the database
            mInvDb = InventoryDatabase.getInstance(getApplicationContext());

            // setup login buttons
            mLoginButton = findViewById(R.id.loginButton);
            mRegisterButton = findViewById(R.id.newUserButton);

            mLoginButton.setOnClickListener(this);
            mRegisterButton.setOnClickListener(this);

            // setup views
            mUserText = findViewById(R.id.userEntry);
            mPassText = findViewById(R.id.passwordEntry);
        }

        @SuppressLint("NonConstantResourceId")
        @Override
        public void onClick(View view) {
            User tempUser = new User();

            switch (view.getId()) {
                case R.id.loginButton:
                    // create a temp user to check against
                    tempUser.setUser(mUserText.getText().toString());
                    tempUser.setPass(mPassText.getText().toString());
                    // check the temp user against the database
                    if (mInvDb.checkUser(tempUser)){
                        Toast.makeText(getApplicationContext(),"Successful login!"
                                , Toast.LENGTH_LONG).show();
                        // this is a successful login proceeed to inventory dashboard
                        // Inventory Activity Intent
                        Intent intent = new Intent(this, GridDisplayActivity.class);
                        // start GridDisplayActivity
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(getApplicationContext(),"Login credentials are invalid, " +
                                "please try again.", Toast.LENGTH_LONG).show();
                    }
                    break;
                case R.id.newUserButton:
                    // create the new user
                    tempUser.setUser(mUserText.getText().toString());
                    tempUser.setPass(mPassText.getText().toString());
                    // add them to the database
                    mInvDb.addUser(tempUser);
                    break;
            }
        }
    }
}
