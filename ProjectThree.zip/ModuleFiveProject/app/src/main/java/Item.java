public class Item {

    private String mName;
    private String mDesc;
    private String mQty;

    public Item(){}

    // setter methods
    public void setName(String name){
        this.mName = name;
    }

    public void setDesc(String desc){
        this.mDesc = desc;
    }

    public void setQty(String qty){
        this.mQty = qty;
    }

    // getter methods
    public String getName(){
        return mName;
    }

    public String getDesc(){
        return mDesc;
    }

    public String getQty(){
        return mQty;
    }

}


