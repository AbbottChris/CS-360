package com.zybooks.modulefiveproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private int SMS PERMISSION CODE = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonRequest = findViewById(R.id.button);
        buttonRequest.setOnClickListener(new View.OnClickListener()   {

            @Override
            public void onClick(View view) {
                Context context;
                if (ContextCompat.checkSelfPermission(context, MainActivity.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
                    ;
                Toast.makeText(MainActivity.this, "You have already granted this permission!", Toast.LENGTH_SHORT).show();
            } else  {
                requestSMSPermission();

            }
        });
    }
        private void requestStoragePermission()   {
            if (ActivityCombat.shouldShowReauestPermsissionRationale(activity:this, Manifest.permission.SEND_SMS)
        }
}