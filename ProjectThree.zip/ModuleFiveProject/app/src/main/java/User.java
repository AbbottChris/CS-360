public class User {

    private long mId;
    private String userName;
    private String password;

    public User(){}

    // setter methods
    public void setId(long id){
        this.mId = id;
    }

    public void setUser(String user){
        this.userName = user;
    }

    public void setPass(String pass){
        this.password = pass;
    }

    //getter methods
    public String getUser(){
        return userName;
    }

    public String getPassword(){
        return password;
    }

}

}
